Planets.tantros.accessible = Planets.tantros.alwaysUnlocked = Planets.tantros.visible = true
Planets.tantros.deafultCore = Vars.content.getByName(ContentType.block, "tantros-core-ruin"
