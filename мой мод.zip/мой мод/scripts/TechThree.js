block.router.requirements =
        { copper/3 }
        { research/1 }
 
